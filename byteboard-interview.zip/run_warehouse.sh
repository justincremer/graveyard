#!/usr/bin/env bash

go run runner.go
