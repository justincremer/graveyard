## Scavenger Hunt - Moduel 2 ##

### PART 1 ###

  - Take screenshots of the following directories:
    - Downloads directory
    - Any directroy nestsed three times
    - Any jpeg

### PART 2 ###

  - Research about google chrome
    - Cache
    - Incognito windows
    - Access conrtols (Google Drive)
  - Write a response in a Google Drive doc
  - Export the doc as a pdf
REF: 
https://coding-bootcamp-cybersecurity-prework.readthedocs-hosted.com/en/latest/modules/SH-Docs/Part-2-Help/

### PART 3 ###

  - Combine files into a zipped directory

###############################
