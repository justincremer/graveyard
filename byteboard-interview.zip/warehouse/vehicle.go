package warehouse

import (
	"fmt"
)

// Vehicle represents a named vehicle with a sequence of pings.
type Vehicle struct {
	Name  string
	Pings []*Ping
}

// TotalDistance returns the total distance traveled by the vehicle.
func (v *Vehicle) TotalDistance() float64 {
	return TotalDistance(v.Pings)
}

// AverageSpeed returns the average speed of the vehicle.
func (v *Vehicle) AverageSpeed() float64 {
	// TODO: Implement.
	return 0.0
}

// String returns a string representation of the vehicle.
func (v *Vehicle) String() string {
	return fmt.Sprintf("%s: %v", v.Name, v.Pings)
}

// TotalDistance returns the total distance covered by the specified pings.
func TotalDistance(pings []*Ping) float64 {
	// TODO: Implement.
	return 0.0
}
