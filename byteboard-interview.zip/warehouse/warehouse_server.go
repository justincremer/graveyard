// package warehouse contains the warehouse server code and related structs/utilities for assessing vehicle usage.
package warehouse

import (
	"encoding/csv"
	"os"
	"strconv"
	"time"
)

// Server implements the warehouse server APIs.
type Server struct {
	vehicles []*Vehicle
}

// AverageSpeeds returns a map from vehicle name to that vehicle's average speed for all vehicles.
func (s *Server) AverageSpeeds() map[string]float64 {
	speeds := make(map[string]float64)
	for _, v := range s.vehicles {
		speeds[v.Name] = v.AverageSpeed()
	}
	return speeds
}

// MostTraveledSince returns a sorted slice of maxResults vehicle names corresponding to the vehicles that have traveled the most distance since the given timestamp.
func (s *Server) MostTraveledSince(maxResults int, timestamp time.Time) []string {
	// TODO: Implement.
	return nil
}

// CheckForDamage returns a list of names identifying vehicles that might have been damaged through any number of risky behaviors, including collision with another vehicle and excessive acceleration.
func (s *Server) CheckForDamage() []string {
	// TODO: Implement.
	return nil
}

func (s *Server) processPing(vehicleName string, x, y float64, time time.Time) {
	p := &Ping{Position: &Position{X: x, Y: y}, Time: time}
	if len(s.vehicles) == 0 || vehicleName != s.vehicles[len(s.vehicles)-1].Name {
		s.vehicles = append(s.vehicles, &Vehicle{Name: vehicleName})

	}
	s.vehicles[len(s.vehicles)-1].Pings = append(s.vehicles[len(s.vehicles)-1].Pings, p)
}

// NewServerFromFile reads an appropriately-formatted CSV of ping data and returns a new Server initialized with the loaded data.
func NewServerFromFile(filename string) (*Server, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	csvReader := csv.NewReader(file)
	s := &Server{}
	records, err := csvReader.ReadAll()
	if err != nil {
		return nil, err
	}
	for _, record := range records {
		name := record[0]
		x, err := strconv.Atoi(record[1])
		if err != nil {
			return nil, err
		}
		y, err := strconv.Atoi(record[2])
		if err != nil {
			return nil, err
		}
		timestamp, err := strconv.Atoi(record[3])
		if err != nil {
			return nil, err
		}
		s.processPing(name, float64(x), float64(y), time.Unix(int64(timestamp), 0))
	}
	return s, nil
}
